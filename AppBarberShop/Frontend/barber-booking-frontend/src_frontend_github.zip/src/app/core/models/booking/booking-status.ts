export enum BookingStatus{
  IN_ATTESA = "IN_ATTESA",
  CONFERMATA = "CONFERMATA",
  ANNULLATA = "ANNULLATA"
}
